# tugas-js-basic
Tugas untuk basic javascript january
